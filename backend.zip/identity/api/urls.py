from django.urls import path
from . import views

urlpatterns = [
    # path('',views.getRoutes,name="routes"),
    path('test',views.test,name="Test"),
    path('question',views.getQuestions,name="Question"),
    path('sendIdentity/pancard',views.pancard,name="Context"),
    path('sendIdentity/passport',views.passport,name="Context"),
    path('sendIdentity/Aadhaar',views.passport,name="Context")
]