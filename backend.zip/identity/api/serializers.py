from rest_framework.serializers import ModelSerializer
from .models import Paragraph
class ParagraphSerializer(ModelSerializer):
    class Meta:
        model = Paragraph
        fields = '__all__'
        