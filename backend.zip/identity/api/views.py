from django.http import HttpResponse
from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import Paragraph
from rest_framework.views import APIView
from rest_framework import status
from .serializers import ParagraphSerializer
import easyocr
import datetime
from datetime import date
import cv2
import re
import numpy as np
import requests
import matplotlib.pyplot as plt
import urllib

import firebase_admin
from firebase_admin import credentials, firestore

import traceback
import csv
import os
from collections import namedtuple
from mindee import Client
import requests
import pathlib
import cv2
import re
url = "https://api.mindee.net/v1/products/mindee/passport/v1/predict"
cred = credentials.Certificate("/content/drive/MyDrive/identity/serviceAccountKey.json")
firebase_admin.initialize_app(cred)
firestore_db = firestore.client()
reader = easyocr.Reader(['en','hi'],gpu=True)
mindee_client = Client().config_passport("f9f321e41ffd0d1caf4b238a4c3d3fd1")

def passportExtract(myFile):

  with open(myFile, "rb") as myfile:
    files = {"document": myfile}
    headers = {"Authorization": "Token f9f321e41ffd0d1caf4b238a4c3d3fd1"}
    response = requests.post(url, files=files, headers=headers)
    img =cv2.imread(myFile)
    data = ocr(img)
    dob =  re.search(r'\d{2}/\d{2}/\d{4}', data)
    return response.text,dob.group()

def ext(test_string,dob):
    res = json.loads(test_string)
    data=res['document']['inference']['pages'][0]['prediction']
    birth_place = data['country']['value']
    given_name = data['given_names']
    name = ""
    for i in range(len(given_name)):
      name= name+" "+given_name[i]['value']
    passport_no = data['id_number']['value']
    return name, passport_no, birth_place,dob

def variance_of_laplacian(image):
	return cv2.Laplacian(image, cv2.CV_64F).var()

def url_to_image(url):
  resp = urllib.request.urlopen(url)
  image = np.asarray(bytearray(resp.read()), dtype="uint8")
  image = cv2.imdecode(image, cv2.IMREAD_COLOR)
  return image

def get_quality(img):
  img1 = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
  quality_score = variance_of_laplacian(img1)
  return quality_score

def ocr(img):
  img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
  result = reader.readtext(img,detail=1,paragraph=False)
  st=""
  for item in result:
    st= st+" "+item[1]
  print(st)
  return st

def database2(passport_name): 
  val=passport_name
  snapshots = list(firestore_db.collection(u'Passport').get())
  for snapshot in snapshots:
      snapshot=snapshot.to_dict()
      if snapshot["Passport"].lower()==val.lower():
          return snapshot

def database(pan_id):
  val=pan_id
  snapshots = list(firestore_db.collection(u'PAN').get())
  for snapshot in snapshots:
      snapshot=snapshot.to_dict()
      if snapshot["PAN ID"].lower()==val.lower():
          return snapshot
def passport(request):
  path = str(request.data.get('image'))
  img = url_to_image(path)
  quality = get_quality(img)/1500
  test_string,dob=passportExtract(path)
  b,d=passportExtract(test_string)
  data = ext(b,d)
  name = data[0]
  identity = data[1]
  birth_country = data[2]
  dob = data[3]
  temp = database2(name)
  if(temp['DOB'].lower()==dob):
    return {}
  return False,quality

def pan_verification(img):
  quality_score = get_quality(img)
  if(quality_score<100):
    return (False,quality_score/1500)
  print("Quality_score: ",quality_score)
  quality_score/=1500
  name = None
  fathers_name=None
  pan_no = None
  dob = None
  data = ocr(img)
  data =data.lower()
  lst = data.split(" ")
  pan_no = lst[lst.index('card') + 1]
  name = lst[lst.index('name') + 1]+" "+lst[lst.index('name') + 2]
  fathers_name =None
  dob =  re.search(r'\d{2}/\d{2}/\d{4}', data)
  # dob=datetime.datetime.strptime(dob.group(), '%d/%m/%Y').date()
  dob = dob.group()
  for i in range(len(lst)):
    if lst[i] == 'name':
      fathers_name = lst[i+1]+" "+lst[i+2]
  extracted_data =  {"Pan_Id" :pan_no,
  "Name" :name,
  "Father_Name": fathers_name,
  "DOB": dob}
  
  temp = database(extracted_data["Pan_Id"])
  print("database: ",temp)
  print("Extracted: ",extracted_data)
  if(temp['Name'].lower() == data['Name'] ):
    return Response({'required_field': True,'quality': quality_score});
  else:
    return Response({'required_field': False,'quality': quality_score});
@api_view(['POST'])
def test():
  print("called...")
  


@api_view(['POST'])
def pancard(request):
  path = str(request.data.get('image'))
  img = url_to_image(path)
  print(img)
  check,quality = pan_verification(img)
  return Response({'required_field': check,'quality': quality})

@api_view(['POST'])
def passport(request):
  path = str(request.data.get('image'))
  img = url_to_image(path)
  quality = pan_verification(img)
  return Response({'quality': quality})

@api_view(['GET'])
def getQuestions(request):
    content=Paragraph.objects.all()
    serializer = ParagraphSerializer(content,many=True)
    return Response(serializer.data)