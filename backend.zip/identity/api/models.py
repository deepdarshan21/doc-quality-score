from django.db import models

# Create your models here.

class Paragraph(models.Model):
    content = models.TextField(null=False, blank=False)
    def __str__(self):
        return self.content[0:50]